PÁGINA INTERACTIVA PARA LORENITA

1. Sube index.html y flores_lorenita.png al repositorio de GitHub.
2. GitHub: Settings > Pages.
3. En "Build and deployment", selecciona "Deploy from a branch".
4. Branch: main / Folder: /(root) > Save.
5. Espera unos minutos y abre el enlace que GitHub mostrará.
